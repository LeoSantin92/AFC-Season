// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Container } from 'react-bootstrap';
import { Provider } from 'react-redux';
import store from './redux/store';

// Import styles
import 'bootstrap/dist/css/bootstrap.min.css';
import './components/exercises/ExerciseStyles.css';
import './components/age-group/AgeGroupStyles.css';
import './components/planning/PlanningStyles.css';

// Import components
import NavBar from './components/common/NavBar';
import Dashboard from './pages/Dashboard';
import ExerciseDatabase from './components/exercises/ExerciseDatabase';
import ExerciseDetail from './components/exercises/ExerciseDetail';
import ExerciseForm from './components/exercises/ExerciseForm';
import AgeGroupDashboard from './components/age-group/AgeGroupDashboard';
import AgeGroupOverview from './components/age-group/AgeGroupOverview';
import MacrocycleView from './components/planning/MacrocycleView';

function App() {
  return (
    <Provider store={store}>
      <Router>
        <div className="App">
          <NavBar />
          <Container className="mt-4">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              
              {/* Exercise routes */}
              <Route path="/exercises" element={<ExerciseDatabase />} />
              <Route path="/exercises/:id" element={<ExerciseDetail />} />
              <Route path="/exercises/new" element={<ExerciseForm />} />
              <Route path="/exercises/edit/:id" element={<ExerciseForm />} />
              
              {/* Age Group routes */}
              <Route path="/age-groups" element={<AgeGroupDashboard />} />
              <Route path="/age-group/:id" element={<AgeGroupOverview />} />
              <Route path="/age-group/edit/:id" element={<AgeGroupOverview />} />
              
              {/* Season Planning routes */}
              <Route path="/age-group/:id/macrocycle" element={<MacrocycleView />} />
              <Route path="/macrocycle/:id/mesocycles" element={<MacrocycleView />} />
            </Routes>
          </Container>
        </div>
      </Router>
    </Provider>
  );
}

export default App;
