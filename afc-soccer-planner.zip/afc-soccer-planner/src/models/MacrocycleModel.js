// src/models/MacrocycleModel.js
export class MacrocycleModel {
  constructor(data = {}) {
    this.id = data.id || null;
    this.ageGroupPlanId = data.ageGroupPlanId || null;
    this.name = data.name || 'Season Plan';
    this.startDate = data.startDate || new Date().toISOString().split('T')[0];
    this.endDate = data.endDate || new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split('T')[0];
    this.seasonPhases = data.seasonPhases || this.getDefaultSeasonPhases();
    this.seasonGoals = data.seasonGoals || {
      technical: '',
      tactical: '',
      physical: '',
      psychosocial: ''
    };
    this.notes = data.notes || '';
    this.createdAt = data.createdAt || new Date();
    this.updatedAt = data.updatedAt || new Date();
  }

  getDefaultSeasonPhases() {
    return [
      {
        id: 'phase1',
        name: 'Pre-Season',
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString().split('T')[0],
        focus: 'Physical preparation and basic technical skills',
        color: '#28a745' // Green
      },
      {
        id: 'phase2',
        name: 'Early Season',
        startDate: new Date(new Date().setMonth(new Date().getMonth() + 1, 1)).toISOString().split('T')[0],
        endDate: new Date(new Date().setMonth(new Date().getMonth() + 2)).toISOString().split('T')[0],
        focus: 'Technical development and basic tactical concepts',
        color: '#17a2b8' // Teal
      },
      {
        id: 'phase3',
        name: 'Mid Season',
        startDate: new Date(new Date().setMonth(new Date().getMonth() + 2, 1)).toISOString().split('T')[0],
        endDate: new Date(new Date().setMonth(new Date().getMonth() + 4)).toISOString().split('T')[0],
        focus: 'Tactical development and team play',
        color: '#007bff' // Blue
      },
      {
        id: 'phase4',
        name: 'Late Season',
        startDate: new Date(new Date().setMonth(new Date().getMonth() + 4, 1)).toISOString().split('T')[0],
        endDate: new Date(new Date().setMonth(new Date().getMonth() + 5)).toISOString().split('T')[0],
        focus: 'Competitive preparation and performance',
        color: '#dc3545' // Red
      },
      {
        id: 'phase5',
        name: 'Post-Season',
        startDate: new Date(new Date().setMonth(new Date().getMonth() + 5, 1)).toISOString().split('T')[0],
        endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split('T')[0],
        focus: 'Recovery and individual development',
        color: '#6c757d' // Gray
      }
    ];
  }

  toJSON() {
    return {
      id: this.id,
      ageGroupPlanId: this.ageGroupPlanId,
      name: this.name,
      startDate: this.startDate,
      endDate: this.endDate,
      seasonPhases: this.seasonPhases,
      seasonGoals: this.seasonGoals,
      notes: this.notes,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }
}
