// src/redux/ageGroupSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { 
  getAgeGroupPlans, 
  getAgeGroupPlan, 
  createAgeGroupPlan, 
  updateAgeGroupPlan, 
  deleteAgeGroupPlan,
  duplicateAgeGroupPlan
} from '../services/ageGroupService';

// Async thunks
export const fetchAgeGroupPlans = createAsyncThunk(
  'ageGroup/fetchAgeGroupPlans',
  async (userId, { rejectWithValue }) => {
    try {
      return await getAgeGroupPlans(userId);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchAgeGroupPlan = createAsyncThunk(
  'ageGroup/fetchAgeGroupPlan',
  async (id, { rejectWithValue }) => {
    try {
      return await getAgeGroupPlan(id);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const addAgeGroupPlan = createAsyncThunk(
  'ageGroup/addAgeGroupPlan',
  async (ageGroupPlan, { rejectWithValue }) => {
    try {
      return await createAgeGroupPlan(ageGroupPlan);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const editAgeGroupPlan = createAsyncThunk(
  'ageGroup/editAgeGroupPlan',
  async ({ id, ageGroupPlan }, { rejectWithValue }) => {
    try {
      return await updateAgeGroupPlan(id, ageGroupPlan);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const removeAgeGroupPlan = createAsyncThunk(
  'ageGroup/removeAgeGroupPlan',
  async (id, { rejectWithValue }) => {
    try {
      await deleteAgeGroupPlan(id);
      return id;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const cloneAgeGroupPlan = createAsyncThunk(
  'ageGroup/cloneAgeGroupPlan',
  async ({ id, userId }, { rejectWithValue }) => {
    try {
      return await duplicateAgeGroupPlan(id, userId);
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

// Initial state
const initialState = {
  ageGroupPlans: [],
  currentAgeGroupPlan: null,
  status: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
  error: null
};

// Slice
const ageGroupSlice = createSlice({
  name: 'ageGroup',
  initialState,
  reducers: {
    clearCurrentAgeGroupPlan: (state) => {
      state.currentAgeGroupPlan = null;
    },
    setCurrentAgeGroupPlan: (state, action) => {
      state.currentAgeGroupPlan = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder
      // Fetch all age group plans
      .addCase(fetchAgeGroupPlans.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchAgeGroupPlans.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.ageGroupPlans = action.payload;
      })
      .addCase(fetchAgeGroupPlans.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      
      // Fetch single age group plan
      .addCase(fetchAgeGroupPlan.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchAgeGroupPlan.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.currentAgeGroupPlan = action.payload;
      })
      .addCase(fetchAgeGroupPlan.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      
      // Add age group plan
      .addCase(addAgeGroupPlan.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(addAgeGroupPlan.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.ageGroupPlans.push(action.payload);
      })
      .addCase(addAgeGroupPlan.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      
      // Edit age group plan
      .addCase(editAgeGroupPlan.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(editAgeGroupPlan.fulfilled, (state, action) => {
        state.status = 'succeeded';
        const index = state.ageGroupPlans.findIndex(plan => plan.id === action.payload.id);
        if (index !== -1) {
          state.ageGroupPlans[index] = action.payload;
        }
        if (state.currentAgeGroupPlan && state.currentAgeGroupPlan.id === action.payload.id) {
          state.currentAgeGroupPlan = action.payload;
        }
      })
      .addCase(editAgeGroupPlan.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      
      // Remove age group plan
      .addCase(removeAgeGroupPlan.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(removeAgeGroupPlan.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.ageGroupPlans = state.ageGroupPlans.filter(plan => plan.id !== action.payload);
        if (state.currentAgeGroupPlan && state.currentAgeGroupPlan.id === action.payload) {
          state.currentAgeGroupPlan = null;
        }
      })
      .addCase(removeAgeGroupPlan.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      })
      
      // Clone age group plan
      .addCase(cloneAgeGroupPlan.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(cloneAgeGroupPlan.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.ageGroupPlans.push(action.payload);
      })
      .addCase(cloneAgeGroupPlan.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      });
  }
});

// Export actions and reducer
export const { clearCurrentAgeGroupPlan, setCurrentAgeGroupPlan } = ageGroupSlice.actions;
export default ageGroupSlice.reducer;
