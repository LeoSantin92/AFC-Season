// src/models/AgeGroupPlanModel.js
export class AgeGroupPlanModel {
  constructor(data = {}) {
    this.id = data.id || null;
    this.userId = data.userId || null;
    this.name = data.name || 'New Age Group Plan';
    this.ageGroup = data.ageGroup || 'U11-U12';
    this.seasonStart = data.seasonStart || new Date().toISOString().split('T')[0];
    this.seasonEnd = data.seasonEnd || new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split('T')[0];
    this.sessionDuration = data.sessionDuration || this.getDefaultSessionDuration(data.ageGroup);
    this.playersCount = data.playersCount || 16;
    this.sessionsPerWeek = data.sessionsPerWeek || 3;
    this.timeDistribution = data.timeDistribution || this.getDefaultTimeDistribution();
    this.seasonObjectives = data.seasonObjectives || {
      technical: '',
      tactical: '',
      physical: '',
      psychosocial: ''
    };
    this.notes = data.notes || '';
    this.createdAt = data.createdAt || new Date();
    this.updatedAt = data.updatedAt || new Date();
  }

  getDefaultSessionDuration(ageGroup) {
    // Based on AFC-Huntsville session durations
    switch(ageGroup) {
      case 'U4':
        return 45;
      case 'U6':
        return 75;
      case 'U8':
      case 'U9-U10':
      case 'U11-U12':
      case 'U13-U15':
      case 'U16+':
        return 90;
      default:
        return 90;
    }
  }

  getDefaultTimeDistribution() {
    return {
      technical: {
        percentage: 30,
        minutes: 0 // Will be calculated
      },
      tactical: {
        percentage: 30,
        minutes: 0 // Will be calculated
      },
      physical: {
        percentage: 25,
        minutes: 0 // Will be calculated
      },
      psychosocial: {
        percentage: 15,
        minutes: 0 // Will be calculated
      }
    };
  }

  calculateMinutes() {
    const totalMinutes = this.sessionDuration;
    
    // Calculate minutes based on percentages
    const updatedDistribution = { ...this.timeDistribution };
    
    for (const category in updatedDistribution) {
      updatedDistribution[category].minutes = Math.round(
        (updatedDistribution[category].percentage / 100) * totalMinutes
      );
    }
    
    return updatedDistribution;
  }

  validatePercentages() {
    let total = 0;
    for (const category in this.timeDistribution) {
      total += this.timeDistribution[category].percentage;
    }
    return total === 100;
  }

  getAgeGroupColorClass() {
    switch(this.ageGroup) {
      case 'U4':
      case 'U6':
        return 'age-group-u4-u6';
      case 'U7-U8':
        return 'age-group-u7-u8';
      case 'U9-U10':
        return 'age-group-u9-u10';
      case 'U11-U12':
        return 'age-group-u11-u12';
      case 'U13-U15':
        return 'age-group-u13-u15';
      case 'U16+':
        return 'age-group-u16-plus';
      default:
        return '';
    }
  }

  toJSON() {
    return {
      id: this.id,
      userId: this.userId,
      name: this.name,
      ageGroup: this.ageGroup,
      seasonStart: this.seasonStart,
      seasonEnd: this.seasonEnd,
      sessionDuration: this.sessionDuration,
      playersCount: this.playersCount,
      sessionsPerWeek: this.sessionsPerWeek,
      timeDistribution: this.timeDistribution,
      seasonObjectives: this.seasonObjectives,
      notes: this.notes,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }
}
