// src/services/weekPlanService.js
import { db } from '../firebase';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  getDoc,
  query,
  where
} from 'firebase/firestore';

const weekPlansCollectionRef = collection(db, 'weekPlans');

// Get week plans by mesocycle ID
export const getWeekPlansByMesocycleId = async (mesocycleId) => {
  try {
    const q = query(weekPlansCollectionRef, where("mesocycleId", "==", mesocycleId));
    const data = await getDocs(q);
    return data.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
  } catch (error) {
    console.error("Error getting week plans: ", error);
    throw error;
  }
};

// Get a specific week plan
export const getWeekPlan = async (id) => {
  try {
    const weekPlanDoc = await getDoc(doc(db, 'weekPlans', id));
    
    if (weekPlanDoc.exists()) {
      return { id: weekPlanDoc.id, ...weekPlanDoc.data() };
    } else {
      throw new Error('Week plan not found');
    }
  } catch (error) {
    console.error("Error getting week plan: ", error);
    throw error;
  }
};

// Create a new week plan
export const createWeekPlan = async (weekPlan) => {
  try {
    const docRef = await addDoc(weekPlansCollectionRef, {
      ...weekPlan,
      createdAt: new Date()
    });
    return { id: docRef.id, ...weekPlan };
  } catch (error) {
    console.error("Error creating week plan: ", error);
    throw error;
  }
};

// Update an existing week plan
export const updateWeekPlan = async (id, updatedWeekPlan) => {
  try {
    const weekPlanDoc = doc(db, 'weekPlans', id);
    await updateDoc(weekPlanDoc, {
      ...updatedWeekPlan,
      updatedAt: new Date()
    });
    return { id, ...updatedWeekPlan };
  } catch (error) {
    console.error("Error updating week plan: ", error);
    throw error;
  }
};

// Delete a week plan
export const deleteWeekPlan = async (id) => {
  try {
    const weekPlanDoc = doc(db, 'weekPlans', id);
    await deleteDoc(weekPlanDoc);
    return id;
  } catch (error) {
    console.error("Error deleting week plan: ", error);
    throw error;
  }
};
