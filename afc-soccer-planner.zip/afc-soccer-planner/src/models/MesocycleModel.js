// src/models/MesocycleModel.js
export class MesocycleModel {
  constructor(data = {}) {
    this.id = data.id || null;
    this.macrocycleId = data.macrocycleId || null;
    this.name = data.name || 'Mesocycle';
    this.startDate = data.startDate || new Date().toISOString().split('T')[0];
    this.endDate = data.endDate || new Date(new Date().setDate(new Date().getDate() + 28)).toISOString().split('T')[0];
    this.phase = data.phase || 'Pre-Season';
    this.focus = data.focus || '';
    this.objectives = data.objectives || {
      technical: '',
      tactical: '',
      physical: '',
      psychosocial: ''
    };
    this.timeDistribution = data.timeDistribution || {
      technical: { percentage: 30, minutes: 0 },
      tactical: { percentage: 30, minutes: 0 },
      physical: { percentage: 25, minutes: 0 },
      psychosocial: { percentage: 15, minutes: 0 }
    };
    this.notes = data.notes || '';
    this.color = data.color || '#007bff'; // Default blue
    this.createdAt = data.createdAt || new Date();
    this.updatedAt = data.updatedAt || new Date();
  }

  calculateMinutes(sessionDuration) {
    const updatedDistribution = { ...this.timeDistribution };
    
    for (const category in updatedDistribution) {
      updatedDistribution[category].minutes = Math.round(
        (updatedDistribution[category].percentage / 100) * sessionDuration
      );
    }
    
    return updatedDistribution;
  }

  validatePercentages() {
    let total = 0;
    for (const category in this.timeDistribution) {
      total += this.timeDistribution[category].percentage;
    }
    return total === 100;
  }

  toJSON() {
    return {
      id: this.id,
      macrocycleId: this.macrocycleId,
      name: this.name,
      startDate: this.startDate,
      endDate: this.endDate,
      phase: this.phase,
      focus: this.focus,
      objectives: this.objectives,
      timeDistribution: this.timeDistribution,
      notes: this.notes,
      color: this.color,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }
}
