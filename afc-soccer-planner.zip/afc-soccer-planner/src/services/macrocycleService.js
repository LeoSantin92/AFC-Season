// src/services/macrocycleService.js
import { db } from '../firebase';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  getDoc,
  query,
  where
} from 'firebase/firestore';

const macrocyclesCollectionRef = collection(db, 'macrocycles');

// Get macrocycle by age group plan ID
export const getMacrocycleByAgeGroupPlanId = async (ageGroupPlanId) => {
  try {
    const q = query(macrocyclesCollectionRef, where("ageGroupPlanId", "==", ageGroupPlanId));
    const data = await getDocs(q);
    const macrocycles = data.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
    
    // Return the first macrocycle found or null
    return macrocycles.length > 0 ? macrocycles[0] : null;
  } catch (error) {
    console.error("Error getting macrocycle: ", error);
    throw error;
  }
};

// Get a specific macrocycle
export const getMacrocycle = async (id) => {
  try {
    const macrocycleDoc = await getDoc(doc(db, 'macrocycles', id));
    
    if (macrocycleDoc.exists()) {
      return { id: macrocycleDoc.id, ...macrocycleDoc.data() };
    } else {
      throw new Error('Macrocycle not found');
    }
  } catch (error) {
    console.error("Error getting macrocycle: ", error);
    throw error;
  }
};

// Create a new macrocycle
export const createMacrocycle = async (macrocycle) => {
  try {
    const docRef = await addDoc(macrocyclesCollectionRef, {
      ...macrocycle,
      createdAt: new Date()
    });
    return { id: docRef.id, ...macrocycle };
  } catch (error) {
    console.error("Error creating macrocycle: ", error);
    throw error;
  }
};

// Update an existing macrocycle
export const updateMacrocycle = async (id, updatedMacrocycle) => {
  try {
    const macrocycleDoc = doc(db, 'macrocycles', id);
    await updateDoc(macrocycleDoc, {
      ...updatedMacrocycle,
      updatedAt: new Date()
    });
    return { id, ...updatedMacrocycle };
  } catch (error) {
    console.error("Error updating macrocycle: ", error);
    throw error;
  }
};

// Delete a macrocycle
export const deleteMacrocycle = async (id) => {
  try {
    const macrocycleDoc = doc(db, 'macrocycles', id);
    await deleteDoc(macrocycleDoc);
    return id;
  } catch (error) {
    console.error("Error deleting macrocycle: ", error);
    throw error;
  }
};
