// src/components/age-group/AgeGroupOverview.js
import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Form, Spinner, Alert, Table } from 'react-bootstrap';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { FaArrowLeft, FaSave, FaChartPie } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAgeGroupPlan, editAgeGroupPlan } from '../../redux/ageGroupSlice';
import { AgeGroupPlanModel } from '../../models/AgeGroupPlanModel';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';
import './AgeGroupStyles.css';

// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

const AgeGroupOverview = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { currentAgeGroupPlan, status, error } = useSelector(state => state.ageGroup);
  
  const [formData, setFormData] = useState(new AgeGroupPlanModel());
  const [validationError, setValidationError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  
  useEffect(() => {
    if (id) {
      dispatch(fetchAgeGroupPlan(id));
    }
  }, [dispatch, id]);
  
  useEffect(() => {
    if (currentAgeGroupPlan) {
      setFormData(new AgeGroupPlanModel(currentAgeGroupPlan));
    }
  }, [currentAgeGroupPlan]);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'sessionDuration' || name === 'playersCount' || name === 'sessionsPerWeek') {
      setFormData(prev => {
        const updated = new AgeGroupPlanModel({
          ...prev,
          [name]: parseInt(value, 10) || 0
        });
        return updated;
      });
    } else if (name.startsWith('timeDistribution.')) {
      const [_, category, field] = name.split('.');
      setFormData(prev => {
        const updated = new AgeGroupPlanModel({
          ...prev,
          timeDistribution: {
            ...prev.timeDistribution,
            [category]: {
              ...prev.timeDistribution[category],
              [field]: field === 'percentage' ? parseInt(value, 10) || 0 : prev.timeDistribution[category][field]
            }
          }
        });
        return updated;
      });
    } else if (name.startsWith('seasonObjectives.')) {
      const [_, category] = name.split('.');
      setFormData(prev => {
        const updated = new AgeGroupPlanModel({
          ...prev,
          seasonObjectives: {
            ...prev.seasonObjectives,
            [category]: value
          }
        });
        return updated;
      });
    } else {
      setFormData(prev => new AgeGroupPlanModel({
        ...prev,
        [name]: value
      }));
    }
  };
  
  const validateForm = () => {
    // Check if percentages add up to 100%
    let totalPercentage = 0;
    for (const category in formData.timeDistribution) {
      totalPercentage += formData.timeDistribution[category].percentage;
    }
    
    if (totalPercentage !== 100) {
      setValidationError(`Time distribution percentages must add up to 100%. Current total: ${totalPercentage}%`);
      return false;
    }
    
    // Clear any previous validation errors
    setValidationError(null);
    return true;
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    // Calculate minutes based on percentages before saving
    const updatedFormData = new AgeGroupPlanModel({
      ...formData,
      timeDistribution: formData.calculateMinutes()
    });
    
    dispatch(editAgeGroupPlan({ id, ageGroupPlan: updatedFormData.toJSON() }))
      .unwrap()
      .then(() => {
        setSuccessMessage('Age group plan updated successfully!');
        setTimeout(() => {
          setSuccessMessage(null);
        }, 3000);
      })
      .catch(err => {
        setValidationError(`Failed to update plan: ${err}`);
      });
  };
  
  // Prepare chart data
  const chartData = {
    labels: ['Technical', 'Tactical', 'Physical', 'Psychosocial'],
    datasets: [
      {
        data: [
          formData.timeDistribution.technical.percentage,
          formData.timeDistribution.tactical.percentage,
          formData.timeDistribution.physical.percentage,
          formData.timeDistribution.psychosocial.percentage
        ],
        backgroundColor: [
          '#17a2b8', // Teal for Technical
          '#007bff', // Blue for Tactical
          '#28a745', // Green for Physical
          '#ffc107'  // Yellow for Psychosocial
        ],
        borderWidth: 1,
      },
    ],
  };
  
  // Calculate minutes for time distribution table
  const calculateMinutes = (percentage) => {
    return Math.round((percentage / 100) * formData.sessionDuration);
  };
  
  if (status === 'loading') {
    return (
      <Container className="age-group-overview-container">
        <div className="loading-spinner">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      </Container>
    );
  }
  
  return (
    <Container className="age-group-overview-container">
      <div className="age-group-overview-header">
        <h1>{formData.name} - Overview</h1>
        <div>
          <Link to="/age-groups" className="me-2">
            <Button variant="outline-secondary">
              <FaArrowLeft className="me-2" /> Back to Plans
            </Button>
          </Link>
          <Link to={`/age-group/${id}/macrocycle`}>
            <Button variant="outline-primary">
              View Season Plan
            </Button>
          </Link>
        </div>
      </div>
      
      {error && <Alert variant="danger">{error}</Alert>}
      {validationError && <Alert variant="danger">{validationError}</Alert>}
      {successMessage && <Alert variant="success">{successMessage}</Alert>}
      
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={8}>
            <Card className="age-group-section">
              <Card.Body>
                <h3>Basic Information</h3>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Plan Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Age Group</Form.Label>
                      <Form.Select
                        name="ageGroup"
                        value={formData.ageGroup}
                        onChange={handleInputChange}
                      >
                        <option value="U4">U4</option>
                        <option value="U6">U6</option>
                        <option value="U7-U8">U7-U8</option>
                        <option value="U9-U10">U9-U10</option>
                        <option value="U11-U12">U11-U12</option>
                        <option value="U13-U15">U13-U15</option>
                        <option value="U16+">U16+</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                </Row>
                
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Season Start Date</Form.Label>
                      <Form.Control
                        type="date"
                        name="seasonStart"
                        value={formData.seasonStart}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Season End Date</Form.Label>
                      <Form.Control
                        type="date"
                        name="seasonEnd"
                        value={formData.seasonEnd}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                  </Col>
                </Row>
                
                <Row>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Session Duration (minutes)</Form.Label>
                      <Form.Control
                        type="number"
                        name="sessionDuration"
                        value={formData.sessionDuration}
                        onChange={handleInputChange}
                        min="15"
                        max="180"
                      />
                    </Form.Group>
                  </Col>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Number of Players</Form.Label>
                      <Form.Control
                        type="number"
                        name="playersCount"
                        value={formData.playersCount}
                        onChange={handleInputChange}
                        min="1"
                      />
                    </Form.Group>
                  </Col>
                  <Col md={4}>
                    <Form.Group className="mb-3">
                      <Form.Label>Sessions Per Week</Form.Label>
                      <Form.Control
                        type="number"
                        name="sessionsPerWeek"
                        value={formData.sessionsPerWeek}
                        onChange={handleInputChange}
                        min="1"
                        max="7"
                      />
                    </Form.Group>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
            
            <Card className="age-group-section mt-4">
              <Card.Body>
                <h3>Time Distribution</h3>
                <Row>
                  <Col md={6}>
                    <Table className="session-time-table">
                      <thead>
                        <tr>
                          <th>Category</th>
                          <th>Percentage</th>
                          <th>Minutes</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Technical</td>
                          <td>
                            <Form.Control
                              type="number"
                              name="timeDistribution.technical.percentage"
                              value={formData.timeDistribution.technical.percentage}
                              onChange={handleInputChange}
                              min="0"
                              max="100"
                            />
                          </td>
                          <td>{calculateMinutes(formData.timeDistribution.technical.percentage)}</td>
                        </tr>
                        <tr>
                          <td>Tactical</td>
                          <td>
                            <Form.Control
                              type="number"
                              name="timeDistribution.tactical.percentage"
                              value={formData.timeDistribution.tactical.percentage}
                              onChange={handleInputChange}
                              min="0"
                              max="100"
                            />
                          </td>
                          <td>{calculateMinutes(formData.timeDistribution.tactical.percentage)}</td>
                        </tr>
                        <tr>
                          <td>Physical</td>
                          <td>
                            <Form.Control
                              type="number"
                              name="timeDistribution.physical.percentage"
                              value={formData.timeDistribution.physical.percentage}
                              onChange={handleInputChange}
                              min="0"
                              max="100"
                            />
                          </td>
                          <td>{calculateMinutes(formData.timeDistribution.physical.percentage)}</td>
                        </tr>
                        <tr>
                          <td>Psychosocial</td>
                          <td>
                            <Form.Control
                              type="number"
                              name="timeDistribution.psychosocial.percentage"
                              value={formData.timeDistribution.psychosocial.percentage}
                              onChange={handleInputChange}
                              min="0"
                              max="100"
                            />
                          </td>
                          <td>{calculateMinutes(formData.timeDistribution.psychosocial.percentage)}</td>
                        </tr>
                        <tr className="total-row">
                          <td>Total</td>
                          <td>
                            {Object.values(formData.timeDistribution).reduce(
                              (sum, item) => sum + item.percentage, 
                              0
                            )}%
                          </td>
                          <td>{formData.sessionDuration} min</td>
                        </tr>
                      </tbody>
                    </Table>
                  </Col>
                  <Col md={6} className="d-flex align-items-center justify-content-center">
                    <div className="chart-container">
                      <Pie data={chartData} />
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
            
            <Card className="age-group-section mt-4">
              <Card.Body>
                <h3>Season Objectives</h3>
                <Form.Group className="mb-3">
                  <Form.Label>Technical Objectives</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="seasonObjectives.technical"
                    value={formData.seasonObjectives.technical}
                    onChange={handleInputChange}
                    placeholder="Enter technical objectives for the season..."
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Tactical Objectives</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="seasonObjectives.tactical"
                    value={formData.seasonObjectives.tactical}
                    onChange={handleInputChange}
                    placeholder="Enter tactical objectives for the season..."
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Physical Objectives</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="seasonObjectives.physical"
                    value={formData.seasonObjectives.physical}
                    onChange={handleInputChange}
                    placeholder="Enter physical objectives for the season..."
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Psychosocial Objectives</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="seasonObjectives.psychosocial"
                    value={formData.seasonObjectives.psychosocial}
                    onChange={handleInputChange}
                    placeholder="Enter psychosocial objectives for the season..."
                  />
                </Form.Group>
              </Card.Body>
            </Card>
            
            <Card className="age-group-section mt-4">
              <Card.Body>
                <h3>Additional Notes</h3>
                <Form.Group className="mb-3">
                  <Form.Control
                    as="textarea"
                    rows={4}
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="Enter any additional notes about this age group plan..."
                  />
                </Form.Group>
              </Card.Body>
            </Card>
            
            <div className="d-grid gap-2 mt-4 mb-4">
              <Button variant="primary" type="submit" size="lg">
                <FaSave className="me-2" /> Save Age Group Plan
              </Button>
            </div>
          </Col>
          
          <Col md={4}>
            <Card className="age-group-section">
              <Card.Body>
                <h3>Plan Summary</h3>
                <p><strong>Age Group:</strong> {formData.ageGroup}</p>
                <p><strong>Season Duration:</strong> {new Date(formData.seasonStart).toLocaleDateString()} - {new Date(formData.seasonEnd).toLocaleDateString()}</p>
                <p><strong>Session Details:</strong> {formData.sessionsPerWeek} sessions per week, {formData.sessionDuration} minutes each</p>
                <p><strong>Players:</strong> {formData.playersCount}</p>
                
                <h5 className="mt-4">Time Distribution</h5>
                <div>
                  <div className="percentage-label">
                    <span>Technical</span>
                    <span>{formData.timeDistribution.technical.percentage}%</span>
                  </div>
                  <div className="percentage-bar">
                    <div 
                      className="percentage-bar-fill technical" 
                      style={{ width: `${formData.timeDistribution.technical.percentage}%` }}
                    ></div>
                  </div>
                  
                  <div className="percentage-label">
                    <span>Tactical</span>
                    <span>{formData.timeDistribution.tactical.percentage}%</span>
                  </div>
                  <div className="percentage-bar">
                    <div 
                      className="percentage-bar-fill tactical" 
                      style={{ width: `${formData.timeDistribution.tactical.percentage}%` }}
                    ></div>
                  </div>
                  
                  <div className="percentage-label">
                    <span>Physical</span>
                    <span>{formData.timeDistribution.physical.percentage}%</span>
                  </div>
                  <div className="percentage-bar">
                    <div 
                      className="percentage-bar-fill physical" 
                      style={{ width: `${formData.timeDistribution.physical.percentage}%` }}
                    ></div>
                  </div>
                  
                  <div className="percentage-label">
                    <span>Psychosocial</span>
                    <span>{formData.timeDistribution.psychosocial.percentage}%</span>
                  </div>
                  <div className="percentage-bar">
                    <div 
                      className="percentage-bar-fill psychosocial" 
                      style={{ width: `${formData.timeDistribution.psychosocial.percentage}%` }}
                    ></div>
                  </div>
                </div>
              </Card.Body>
            </Card>
            
            <Card className="age-group-section mt-4">
              <Card.Body>
                <h3>Next Steps</h3>
                <p>After saving your age group plan, you can:</p>
                <ul>
                  <li>Create a season plan (macrocycle)</li>
                  <li>Define mesocycles (4-6 week blocks)</li>
                  <li>Plan weekly sessions</li>
                  <li>Create detailed training sessions</li>
                </ul>
                <div className="d-grid gap-2 mt-3">
                  <Button variant="outline-primary" disabled={!id}>
                    <FaChartPie className="me-2" /> Create Season Plan
                  </Button>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Form>
    </Container>
  );
};

export default AgeGroupOverview;
