// src/models/SessionPlanModel.js
export class SessionPlanModel {
  constructor(data = {}) {
    this.id = data.id || null;
    this.weekPlanId = data.weekPlanId || null;
    this.day = data.day || 'Monday';
    this.date = data.date || new Date().toISOString().split('T')[0];
    this.duration = data.duration || 90; // Default 90 minutes
    this.type = data.type || 'Progressive'; // Progressive, Progressive-Regressive, Regressive
    this.focus = data.focus || '';
    this.objectives = data.objectives || {
      technical: '',
      tactical: '',
      physical: '',
      psychosocial: ''
    };
    this.timeDistribution = data.timeDistribution || {
      technical: { percentage: 30, minutes: 0 },
      tactical: { percentage: 30, minutes: 0 },
      physical: { percentage: 25, minutes: 0 },
      psychosocial: { percentage: 15, minutes: 0 }
    };
    this.exercises = data.exercises || [];
    this.notes = data.notes || '';
    this.createdAt = data.createdAt || new Date();
    this.updatedAt = data.updatedAt || new Date();
  }

  // Calculate minutes based on percentages
  calculateMinutes() {
    const updatedDistribution = { ...this.timeDistribution };
    
    for (const category in updatedDistribution) {
      updatedDistribution[category].minutes = Math.round(
        (updatedDistribution[category].percentage / 100) * this.duration
      );
    }
    
    return updatedDistribution;
  }

  // Validate that percentages add up to 100%
  validatePercentages() {
    let total = 0;
    for (const category in this.timeDistribution) {
      total += this.timeDistribution[category].percentage;
    }
    return total === 100;
  }

  // Generate default session structure based on session type
  generateDefaultStructure() {
    const structure = [];
    
    // Different structure based on session type
    switch(this.type) {
      case 'Progressive':
        // Start simple, gradually increase complexity
        structure.push(
          { name: 'Warm-up', duration: 15, type: 'Physical', description: 'Dynamic warm-up with ball' },
          { name: 'Technical Work', duration: 20, type: 'Technical', description: 'Basic technical skills' },
          { name: 'Small-Sided Game (Simple)', duration: 20, type: 'Tactical', description: 'Simple rules and constraints' },
          { name: 'Small-Sided Game (Complex)', duration: 25, type: 'Tactical', description: 'More complex rules and constraints' },
          { name: 'Cool Down', duration: 10, type: 'Physical', description: 'Light activity and stretching' }
        );
        break;
        
      case 'Progressive-Regressive':
        // Start simple, increase complexity, then decrease
        structure.push(
          { name: 'Warm-up', duration: 15, type: 'Physical', description: 'Dynamic warm-up with ball' },
          { name: 'Technical Work', duration: 15, type: 'Technical', description: 'Basic technical skills' },
          { name: 'Small-Sided Game (Simple)', duration: 15, type: 'Tactical', description: 'Simple rules and constraints' },
          { name: 'Small-Sided Game (Complex)', duration: 20, type: 'Tactical', description: 'More complex rules and constraints' },
          { name: 'Small-Sided Game (Simple)', duration: 15, type: 'Tactical', description: 'Return to simpler format' },
          { name: 'Cool Down', duration: 10, type: 'Physical', description: 'Light activity and stretching' }
        );
        break;
        
      case 'Regressive':
        // Start complex, gradually simplify
        structure.push(
          { name: 'Warm-up', duration: 15, type: 'Physical', description: 'Dynamic warm-up with ball' },
          { name: 'Small-Sided Game (Complex)', duration: 25, type: 'Tactical', description: 'Complex rules and constraints' },
          { name: 'Small-Sided Game (Medium)', duration: 20, type: 'Tactical', description: 'Medium complexity' },
          { name: 'Small-Sided Game (Simple)', duration: 20, type: 'Tactical', description: 'Simple rules and constraints' },
          { name: 'Cool Down', duration: 10, type: 'Physical', description: 'Light activity and stretching' }
        );
        break;
        
      default:
        // Default structure
        structure.push(
          { name: 'Warm-up', duration: 15, type: 'Physical', description: 'Dynamic warm-up with ball' },
          { name: 'Technical Work', duration: 25, type: 'Technical', description: 'Technical skills practice' },
          { name: 'Tactical Activity', duration: 25, type: 'Tactical', description: 'Tactical exercise' },
          { name: 'Small-Sided Game', duration: 15, type: 'Tactical', description: 'Game-like activity' },
          { name: 'Cool Down', duration: 10, type: 'Physical', description: 'Light activity and stretching' }
        );
    }
    
    return structure;
  }

  toJSON() {
    return {
      id: this.id,
      weekPlanId: this.weekPlanId,
      day: this.day,
      date: this.date,
      duration: this.duration,
      type: this.type,
      focus: this.focus,
      objectives: this.objectives,
      timeDistribution: this.timeDistribution,
      exercises: this.exercises,
      notes: this.notes,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }
}
