// src/components/exercises/ExerciseForm.js
import React, { useState, useEffect } from 'react';
import { Container, Form, Button, Card, Row, Col, Alert, Spinner } from 'react-bootstrap';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { FaArrowLeft, FaArrowRight, FaSave, FaCheck } from 'react-icons/fa';
import { getDoc, doc } from 'firebase/firestore';
import { db } from '../../firebase';
import { addExercise, updateExercise } from '../../services/exerciseService';
import './ExerciseStyles.css';

const ExerciseForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditMode = !!id;
  
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(isEditMode);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    subcategory: '',
    objectives: '',
    description: '',
    playerCount: '',
    duration: '',
    fieldSize: '',
    equipment: '',
    setup: '',
    coachingPoints: '',
    progressions: '',
    ageGroups: []
  });
  
  const [imageFile, setImageFile] = useState(null);
  
  const ageGroupOptions = [
    'U4', 'U6', 'U8', 'U9-U10', 'U11-U12', 'U13-U15', 'U16+'
  ];
  
  const categoryOptions = [
    { value: 'Technical', label: 'Technical' },
    { value: 'Tactical', label: 'Tactical' },
    { value: 'Physical', label: 'Physical' },
    { value: 'Psychosocial', label: 'Psychosocial' }
  ];
  
  const subcategoryOptions = {
    Technical: ['Dribbling', 'Passing', 'Receiving', 'Shooting', 'Ball Control', 'Heading', 'Other'],
    Tactical: ['Attacking Principles', 'Defending Principles', 'Small-Sided Games', 'Positional Play', 'Set Pieces', 'Other'],
    Physical: ['Speed', 'Agility', 'Strength', 'Endurance', 'Coordination', 'Flexibility', 'Other'],
    Psychosocial: ['Communication', 'Decision Making', 'Teamwork', 'Leadership', 'Confidence', 'Other']
  };

  useEffect(() => {
    if (isEditMode) {
      const fetchExercise = async () => {
        try {
          setLoading(true);
          const exerciseDoc = await getDoc(doc(db, 'exercises', id));
          
          if (exerciseDoc.exists()) {
            const exerciseData = exerciseDoc.data();
            setFormData({
              name: exerciseData.name || '',
              category: exerciseData.category || '',
              subcategory: exerciseData.subcategory || '',
              objectives: exerciseData.objectives || '',
              description: exerciseData.description || '',
              playerCount: exerciseData.playerCount || '',
              duration: exerciseData.duration || '',
              fieldSize: exerciseData.fieldSize || '',
              equipment: exerciseData.equipment || '',
              setup: exerciseData.setup || '',
              coachingPoints: exerciseData.coachingPoints || '',
              progressions: exerciseData.progressions || '',
              ageGroups: exerciseData.ageGroups || []
            });
            
            if (exerciseData.imageUrl) {
              setImagePreview(exerciseData.imageUrl);
            }
          } else {
            setError('Exercise not found');
            navigate('/exercises');
          }
          
          setLoading(false);
        } catch (err) {
          setError('Failed to load exercise. Please try again later.');
          setLoading(false);
          console.error(err);
        }
      };

      fetchExercise();
    }
  }, [id, isEditMode, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleAgeGroupChange = (e) => {
    const value = e.target.value;
    setFormData({
      ...formData,
      ageGroups: formData.ageGroups.includes(value)
        ? formData.ageGroups.filter(group => group !== value)
        : [...formData.ageGroups, value]
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImageFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.name) {
      setError('Exercise name is required');
      return;
    }
    
    if (!formData.category) {
      setError('Category is required');
      return;
    }
    
    if (formData.ageGroups.length === 0) {
      setError('At least one age group must be selected');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      if (isEditMode) {
        await updateExercise(id, formData, imageFile);
        setSuccess('Exercise updated successfully!');
      } else {
        const newExercise = await addExercise(formData, imageFile);
        setSuccess('Exercise created successfully!');
        // Reset form after successful creation
        setFormData({
          name: '',
          category: '',
          subcategory: '',
          objectives: '',
          description: '',
          playerCount: '',
          duration: '',
          fieldSize: '',
          equipment: '',
          setup: '',
          coachingPoints: '',
          progressions: '',
          ageGroups: []
        });
        setImageFile(null);
        setImagePreview(null);
      }
      
      setLoading(false);
      
      // Navigate back to exercises list after a short delay
      setTimeout(() => {
        navigate('/exercises');
      }, 1500);
    } catch (err) {
      setError(`Failed to ${isEditMode ? 'update' : 'create'} exercise: ${err.message}`);
      setLoading(false);
      console.error(err);
    }
  };

  const nextStep = () => {
    setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    setCurrentStep(currentStep - 1);
  };

  if (loading && isEditMode) {
    return (
      <Container className="exercise-form-container">
        <div className="loading-spinner">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      </Container>
    );
  }

  return (
    <Container className="exercise-form-container">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>{isEditMode ? 'Edit Exercise' : 'Create New Exercise'}</h1>
        <Link to="/exercises">
          <Button variant="outline-secondary">
            <FaArrowLeft className="me-2" /> Back to Exercises
          </Button>
        </Link>
      </div>

      {error && <Alert variant="danger">{error}</Alert>}
      {success && <Alert variant="success">{success}</Alert>}

      <div className="step-indicator mb-4">
        <div className={`step ${currentStep === 1 ? 'active' : currentStep > 1 ? 'completed' : ''}`}>
          {currentStep > 1 ? <FaCheck /> : 1}
        </div>
        <div className={`step ${currentStep === 2 ? 'active' : currentStep > 2 ? 'completed' : ''}`}>
          {currentStep > 2 ? <FaCheck /> : 2}
        </div>
        <div className={`step ${currentStep === 3 ? 'active' : currentStep > 3 ? 'completed' : ''}`}>
          {currentStep > 3 ? <FaCheck /> : 3}
        </div>
      </div>

      <Form onSubmit={handleSubmit}>
        {currentStep === 1 && (
          <Card className="exercise-form-section">
            <Card.Header>Basic Information</Card.Header>
            <Card.Body>
              <Form.Group className="mb-3">
                <Form.Label>Exercise Name *</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
              </Form.Group>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Category *</Form.Label>
                    <Form.Select
                      name="category"
                      value={formData.category}
                      onChange={handleInputChange}
                      required
                    >
                      <option value="">Select Category</option>
                      {categoryOptions.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Subcategory</Form.Label>
                    <Form.Select
                      name="subcategory"
                      value={formData.subcategory}
                      onChange={handleInputChange}
                      disabled={!formData.category}
                    >
                      <option value="">Select Subcategory</option>
                      {formData.category && subcategoryOptions[formData.category]?.map(option => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>

              <Form.Group className="mb-3">
                <Form.Label>Age Groups *</Form.Label>
                <div>
                  {ageGroupOptions.map(ageGroup => (
                    <Form.Check
                      key={ageGroup}
                      inline
                      type="checkbox"
                      id={`age-group-${ageGroup}`}
                      label={ageGroup}
                      value={ageGroup}
                      checked={formData.ageGroups.includes(ageGroup)}
                      onChange={handleAgeGroupChange}
                    />
                  ))}
                </div>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Objectives *</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  name="objectives"
                  value={formData.objectives}
                  onChange={handleInputChange}
                  required
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Exercise Image</Form.Label>
                <Form.Control
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                />
                <Form.Text className="text-muted">
                  Upload an image showing the exercise setup or diagram.
                </Form.Text>
                {imagePreview && (
                  <div className="mt-2">
                    <img
                      src={imagePreview}
                      alt="Exercise preview"
                      className="exercise-preview-image"
                    />
                  </div>
                )}
              </Form.Group>
            </Card.Body>
          </Card>
        )}

        {currentStep === 2 && (
          <Card className="exercise-form-section">
            <Card.Header>Exercise Details</Card.Header>
            <Card.Body>
              <Row>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>Number of Players</Form.Label>
                    <Form.Control
                      type="text"
                      name="playerCount"
                      value={formData.playerCount}
                      onChange={handleInputChange}
                    />
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>Duration (minutes)</Form.Label>
                    <Form.Control
                      type="number"
                      name="duration"
                      value={formData.duration}
                      onChange={handleInputChange}
                    />
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group className="mb-3">
                    <Form.Label>Field Size</Form.Label>
                    <Form.Control
                      type="text"
                      name="fieldSize"
                      value={formData.fieldSize}
                      onChange={handleInputChange}
                      placeholder="e.g., 20x30 yards"
                    />
                  </Form.Group>
                </Col>
              </Row>

              <Form.Group className="mb-3">
                <Form.Label>Equipment</Form.Label>
                <Form.Control
                  type="text"
                  name="equipment"
                  value={formData.equipment}
                  onChange={handleInputChange}
                  placeholder="e.g., Cones, balls, bibs"
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={4}
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Setup & Organization</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  name="setup"
                  value={formData.setup}
                  onChange={handleInputChange}
                />
              </Form.Group>
            </Card.Body>
          </Card>
        )}

        {currentStep === 3 && (
          <Card className="exercise-form-section">
            <Card.Header>Coaching Information</Card.Header>
            <Card.Body>
              <Form.Group className="mb-3">
                <Form.Label>Coaching Points</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={4}
                  name="coachingPoints"
                  value={formData.coachingPoints}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Progressions</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={4}
                  name="progressions"
                  value={formData.progressions}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <div className="d-grid gap-2">
                <Button 
                  variant="primary" 
                  type="submit" 
                  disabled={loading}
                  className="mt-3"
                >
                  {loading ? (
                    <>
                      <Spinner
                        as="span"
                        animation="border"
                        size="sm"
                        role="status"
                        aria-hidden="true"
                        className="me-2"
                      />
                      {isEditMode ? 'Updating...' : 'Saving...'}
                    </>
                  ) : (
                    <>
                      <FaSave className="me-2" />
                      {isEditMode ? 'Update Exercise' : 'Save Exercise'}
                    </>
                  )}
                </Button>
              </div>
            </Card.Body>
          </Card>
        )}

        <div className="form-nav">
          {currentStep > 1 && (
            <Button variant="outline-secondary" onClick={prevStep}>
              <FaArrowLeft className="me-2" /> Previous
            </Button>
          )}
          {currentStep < 3 && (
            <Button variant="outline-primary" onClick={nextStep} className="ms-auto">
              Next <FaArrowRight className="ms-2" />
            </Button>
          )}
        </div>
      </Form>
    </Container>
  );
};

export default ExerciseForm;
