// src/services/ageGroupService.js
import { db } from '../firebase';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  getDoc,
  query,
  where
} from 'firebase/firestore';

const ageGroupPlansCollectionRef = collection(db, 'ageGroupPlans');

// Get all age group plans
export const getAgeGroupPlans = async (userId) => {
  try {
    const q = query(ageGroupPlansCollectionRef, where("userId", "==", userId));
    const data = await getDocs(q);
    return data.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
  } catch (error) {
    console.error("Error getting age group plans: ", error);
    throw error;
  }
};

// Get a specific age group plan
export const getAgeGroupPlan = async (id) => {
  try {
    const ageGroupDoc = await getDoc(doc(db, 'ageGroupPlans', id));
    
    if (ageGroupDoc.exists()) {
      return { id: ageGroupDoc.id, ...ageGroupDoc.data() };
    } else {
      throw new Error('Age group plan not found');
    }
  } catch (error) {
    console.error("Error getting age group plan: ", error);
    throw error;
  }
};

// Create a new age group plan
export const createAgeGroupPlan = async (ageGroupPlan) => {
  try {
    const docRef = await addDoc(ageGroupPlansCollectionRef, {
      ...ageGroupPlan,
      createdAt: new Date()
    });
    return { id: docRef.id, ...ageGroupPlan };
  } catch (error) {
    console.error("Error creating age group plan: ", error);
    throw error;
  }
};

// Update an existing age group plan
export const updateAgeGroupPlan = async (id, updatedAgeGroupPlan) => {
  try {
    const ageGroupDoc = doc(db, 'ageGroupPlans', id);
    await updateDoc(ageGroupDoc, {
      ...updatedAgeGroupPlan,
      updatedAt: new Date()
    });
    return { id, ...updatedAgeGroupPlan };
  } catch (error) {
    console.error("Error updating age group plan: ", error);
    throw error;
  }
};

// Delete an age group plan
export const deleteAgeGroupPlan = async (id) => {
  try {
    const ageGroupDoc = doc(db, 'ageGroupPlans', id);
    await deleteDoc(ageGroupDoc);
    return id;
  } catch (error) {
    console.error("Error deleting age group plan: ", error);
    throw error;
  }
};

// Duplicate an age group plan
export const duplicateAgeGroupPlan = async (id, userId) => {
  try {
    const ageGroupDoc = await getDoc(doc(db, 'ageGroupPlans', id));
    
    if (!ageGroupDoc.exists()) {
      throw new Error('Age group plan not found');
    }
    
    const originalPlan = ageGroupDoc.data();
    
    // Create a new plan with the same data but a different name
    const newPlan = {
      ...originalPlan,
      name: `${originalPlan.name} (Copy)`,
      userId,
      createdAt: new Date()
    };
    
    const docRef = await addDoc(ageGroupPlansCollectionRef, newPlan);
    return { id: docRef.id, ...newPlan };
  } catch (error) {
    console.error("Error duplicating age group plan: ", error);
    throw error;
  }
};
