// src/services/sessionPlanService.js
import { db } from '../firebase';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  getDoc,
  query,
  where
} from 'firebase/firestore';

const sessionPlansCollectionRef = collection(db, 'sessionPlans');

// Get session plans by week plan ID
export const getSessionPlansByWeekPlanId = async (weekPlanId) => {
  try {
    const q = query(sessionPlansCollectionRef, where("weekPlanId", "==", weekPlanId));
    const data = await getDocs(q);
    return data.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
  } catch (error) {
    console.error("Error getting session plans: ", error);
    throw error;
  }
};

// Get a specific session plan
export const getSessionPlan = async (id) => {
  try {
    const sessionPlanDoc = await getDoc(doc(db, 'sessionPlans', id));
    
    if (sessionPlanDoc.exists()) {
      return { id: sessionPlanDoc.id, ...sessionPlanDoc.data() };
    } else {
      throw new Error('Session plan not found');
    }
  } catch (error) {
    console.error("Error getting session plan: ", error);
    throw error;
  }
};

// Create a new session plan
export const createSessionPlan = async (sessionPlan) => {
  try {
    const docRef = await addDoc(sessionPlansCollectionRef, {
      ...sessionPlan,
      createdAt: new Date()
    });
    return { id: docRef.id, ...sessionPlan };
  } catch (error) {
    console.error("Error creating session plan: ", error);
    throw error;
  }
};

// Update an existing session plan
export const updateSessionPlan = async (id, updatedSessionPlan) => {
  try {
    const sessionPlanDoc = doc(db, 'sessionPlans', id);
    await updateDoc(sessionPlanDoc, {
      ...updatedSessionPlan,
      updatedAt: new Date()
    });
    return { id, ...updatedSessionPlan };
  } catch (error) {
    console.error("Error updating session plan: ", error);
    throw error;
  }
};

// Delete a session plan
export const deleteSessionPlan = async (id) => {
  try {
    const sessionPlanDoc = doc(db, 'sessionPlans', id);
    await deleteDoc(sessionPlanDoc);
    return id;
  } catch (error) {
    console.error("Error deleting session plan: ", error);
    throw error;
  }
};
