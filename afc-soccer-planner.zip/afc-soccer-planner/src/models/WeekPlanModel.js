// src/models/WeekPlanModel.js
export class WeekPlanModel {
  constructor(data = {}) {
    this.id = data.id || null;
    this.mesocycleId = data.mesocycleId || null;
    this.weekNumber = data.weekNumber || 1;
    this.startDate = data.startDate || new Date().toISOString().split('T')[0];
    this.endDate = data.endDate || new Date(new Date().setDate(new Date().getDate() + 7)).toISOString().split('T')[0];
    this.objectives = data.objectives || {
      technical: '',
      tactical: '',
      physical: '',
      psychosocial: ''
    };
    this.weeklyFocus = data.weeklyFocus || '';
    this.sessionPlans = data.sessionPlans || [];
    this.notes = data.notes || '';
    this.createdAt = data.createdAt || new Date();
    this.updatedAt = data.updatedAt || new Date();
  }

  // Generate default session plans for the week based on sessions per week
  generateDefaultSessionPlans(sessionsPerWeek, sessionDuration) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const sessionPlans = [];
    
    // Create session plans based on sessions per week
    for (let i = 0; i < sessionsPerWeek; i++) {
      if (i < days.length) {
        sessionPlans.push({
          id: `session-${i+1}`,
          day: days[i],
          duration: sessionDuration,
          type: this.getDefaultSessionType(i),
          focus: '',
          exercises: []
        });
      }
    }
    
    return sessionPlans;
  }

  // Get default session type based on day of week
  getDefaultSessionType(dayIndex) {
    // Implement AFC-Huntsville training session types
    // Progressive: Building up complexity
    // Progressive-Regressive: Building up then reducing complexity
    // Regressive: Starting complex and simplifying
    
    switch(dayIndex) {
      case 0: // Monday
        return 'Progressive';
      case 1: // Tuesday
        return 'Progressive-Regressive';
      case 2: // Wednesday
        return 'Regressive';
      case 3: // Thursday
        return 'Progressive';
      default:
        return 'Progressive';
    }
  }

  toJSON() {
    return {
      id: this.id,
      mesocycleId: this.mesocycleId,
      weekNumber: this.weekNumber,
      startDate: this.startDate,
      endDate: this.endDate,
      objectives: this.objectives,
      weeklyFocus: this.weeklyFocus,
      sessionPlans: this.sessionPlans,
      notes: this.notes,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }
}
