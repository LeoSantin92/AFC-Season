// src/redux/store.js
import { configureStore } from '@reduxjs/toolkit';
import ageGroupReducer from './ageGroupSlice';

export const store = configureStore({
  reducer: {
    ageGroup: ageGroupReducer,
    // Add other reducers here as needed
  },
});

export default store;
