// src/components/age-group/AgeGroupDashboard.js
import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Spinner, Alert, Modal, Form } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { FaPlus, FaEdit, FaTrash, FaCopy, FaEye } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import { 
  fetchAgeGroupPlans, 
  removeAgeGroupPlan, 
  addAgeGroupPlan, 
  cloneAgeGroupPlan 
} from '../../redux/ageGroupSlice';
import { AgeGroupPlanModel } from '../../models/AgeGroupPlanModel';
import './AgeGroupStyles.css';

const AgeGroupDashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { ageGroupPlans, status, error } = useSelector(state => state.ageGroup);
  
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPlanName, setNewPlanName] = useState('');
  const [newPlanAgeGroup, setNewPlanAgeGroup] = useState('U11-U12');
  
  // Mock user ID for now - in a real app, this would come from authentication
  const userId = "user123";
  
  useEffect(() => {
    dispatch(fetchAgeGroupPlans(userId));
  }, [dispatch, userId]);
  
  const handleCreatePlan = () => {
    if (!newPlanName.trim()) {
      alert('Please enter a plan name');
      return;
    }
    
    const newPlan = new AgeGroupPlanModel({
      name: newPlanName,
      ageGroup: newPlanAgeGroup,
      userId
    });
    
    dispatch(addAgeGroupPlan(newPlan.toJSON()))
      .unwrap()
      .then(plan => {
        setShowCreateModal(false);
        setNewPlanName('');
        navigate(`/age-group/${plan.id}`);
      })
      .catch(err => {
        console.error('Failed to create plan:', err);
      });
  };
  
  const handleDuplicatePlan = (id) => {
    dispatch(cloneAgeGroupPlan({ id, userId }))
      .unwrap()
      .then(() => {
        // Stay on dashboard to show the new plan
      })
      .catch(err => {
        console.error('Failed to duplicate plan:', err);
      });
  };
  
  const handleDeletePlan = (id) => {
    if (window.confirm('Are you sure you want to delete this age group plan?')) {
      dispatch(removeAgeGroupPlan(id))
        .unwrap()
        .then(() => {
          // Stay on dashboard
        })
        .catch(err => {
          console.error('Failed to delete plan:', err);
        });
    }
  };
  
  const getAgeGroupColorClass = (ageGroup) => {
    switch(ageGroup) {
      case 'U4':
      case 'U6':
        return 'age-group-u4-u6';
      case 'U7-U8':
        return 'age-group-u7-u8';
      case 'U9-U10':
        return 'age-group-u9-u10';
      case 'U11-U12':
        return 'age-group-u11-u12';
      case 'U13-U15':
        return 'age-group-u13-u15';
      case 'U16+':
        return 'age-group-u16-plus';
      default:
        return '';
    }
  };
  
  return (
    <Container className="age-group-container">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>Age Group Plans</h1>
        <Button variant="primary" onClick={() => setShowCreateModal(true)}>
          <FaPlus className="me-2" /> Create New Plan
        </Button>
      </div>
      
      {error && <Alert variant="danger">{error}</Alert>}
      
      {status === 'loading' ? (
        <div className="loading-spinner">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      ) : (
        <>
          {ageGroupPlans.length === 0 ? (
            <Alert variant="info">
              No age group plans found. Create your first plan to get started.
            </Alert>
          ) : (
            <Row xs={1} md={2} lg={3} className="g-4">
              {ageGroupPlans.map(plan => (
                <Col key={plan.id}>
                  <Card className={`age-group-card ${getAgeGroupColorClass(plan.ageGroup)}`}>
                    <Card.Body>
                      <Card.Title>{plan.name}</Card.Title>
                      <Card.Subtitle className="mb-2 text-muted">{plan.ageGroup}</Card.Subtitle>
                      <Card.Text>
                        <strong>Season:</strong> {new Date(plan.seasonStart).toLocaleDateString()} - {new Date(plan.seasonEnd).toLocaleDateString()}
                        <br />
                        <strong>Sessions:</strong> {plan.sessionsPerWeek} per week, {plan.sessionDuration} minutes each
                      </Card.Text>
                      <div className="d-flex justify-content-between mt-3">
                        <Link to={`/age-group/${plan.id}`}>
                          <Button variant="outline-primary" size="sm">
                            <FaEye className="me-1" /> View
                          </Button>
                        </Link>
                        <div>
                          <Button 
                            variant="outline-secondary" 
                            size="sm" 
                            className="me-2"
                            onClick={() => handleDuplicatePlan(plan.id)}
                          >
                            <FaCopy />
                          </Button>
                          <Link to={`/age-group/edit/${plan.id}`} className="me-2">
                            <Button variant="outline-secondary" size="sm">
                              <FaEdit />
                            </Button>
                          </Link>
                          <Button 
                            variant="outline-danger" 
                            size="sm" 
                            onClick={() => handleDeletePlan(plan.id)}
                          >
                            <FaTrash />
                          </Button>
                        </div>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          )}
        </>
      )}
      
      {/* Create Plan Modal */}
      <Modal show={showCreateModal} onHide={() => setShowCreateModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Create New Age Group Plan</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Plan Name</Form.Label>
              <Form.Control 
                type="text" 
                placeholder="Enter plan name" 
                value={newPlanName}
                onChange={(e) => setNewPlanName(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Age Group</Form.Label>
              <Form.Select 
                value={newPlanAgeGroup}
                onChange={(e) => setNewPlanAgeGroup(e.target.value)}
              >
                <option value="U4">U4</option>
                <option value="U6">U6</option>
                <option value="U7-U8">U7-U8</option>
                <option value="U9-U10">U9-U10</option>
                <option value="U11-U12">U11-U12</option>
                <option value="U13-U15">U13-U15</option>
                <option value="U16+">U16+</option>
              </Form.Select>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowCreateModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleCreatePlan}>
            Create Plan
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default AgeGroupDashboard;
