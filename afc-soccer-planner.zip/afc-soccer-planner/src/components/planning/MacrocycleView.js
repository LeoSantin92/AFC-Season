// src/components/planning/MacrocycleView.js
import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Form, Spinner, Alert, Table } from 'react-bootstrap';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { FaArrowLeft, FaSave, FaPlus, FaEdit, FaTrash, FaCalendarAlt } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import { getMacrocycleByAgeGroupPlanId, createMacrocycle, updateMacrocycle } from '../../services/macrocycleService';
import { getAgeGroupPlan } from '../../services/ageGroupService';
import { MacrocycleModel } from '../../models/MacrocycleModel';
import './PlanningStyles.css';

const MacrocycleView = () => {
  const { id } = useParams(); // This is the age group plan ID
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [ageGroupPlan, setAgeGroupPlan] = useState(null);
  const [macrocycle, setMacrocycle] = useState(null);
  const [formData, setFormData] = useState(new MacrocycleModel());
  const [calendarView, setCalendarView] = useState('month'); // 'month' or 'list'
  
  // Fetch age group plan and macrocycle data
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch age group plan
        const ageGroupPlanData = await getAgeGroupPlan(id);
        setAgeGroupPlan(ageGroupPlanData);
        
        // Fetch macrocycle for this age group plan
        const macrocycleData = await getMacrocycleByAgeGroupPlanId(id);
        
        if (macrocycleData) {
          // Existing macrocycle found
          setMacrocycle(macrocycleData);
          setFormData(new MacrocycleModel(macrocycleData));
        } else {
          // No macrocycle found, create a new one with default values
          const newMacrocycle = new MacrocycleModel({
            ageGroupPlanId: id,
            startDate: ageGroupPlanData.seasonStart,
            endDate: ageGroupPlanData.seasonEnd
          });
          setFormData(newMacrocycle);
        }
        
        setLoading(false);
      } catch (err) {
        setError(`Error loading data: ${err.message}`);
        setLoading(false);
        console.error(err);
      }
    };
    
    if (id) {
      fetchData();
    }
  }, [id]);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    if (name.startsWith('seasonGoals.')) {
      const [_, category] = name.split('.');
      setFormData(prev => {
        const updated = new MacrocycleModel({
          ...prev,
          seasonGoals: {
            ...prev.seasonGoals,
            [category]: value
          }
        });
        return updated;
      });
    } else if (name.startsWith('seasonPhases.')) {
      const [_, index, field] = name.split('.');
      setFormData(prev => {
        const updatedPhases = [...prev.seasonPhases];
        updatedPhases[index] = {
          ...updatedPhases[index],
          [field]: value
        };
        
        const updated = new MacrocycleModel({
          ...prev,
          seasonPhases: updatedPhases
        });
        return updated;
      });
    } else {
      setFormData(prev => new MacrocycleModel({
        ...prev,
        [name]: value
      }));
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setLoading(true);
      
      if (macrocycle) {
        // Update existing macrocycle
        await updateMacrocycle(macrocycle.id, formData.toJSON());
        setSuccess('Season plan updated successfully!');
      } else {
        // Create new macrocycle
        const newMacrocycle = await createMacrocycle(formData.toJSON());
        setMacrocycle(newMacrocycle);
        setSuccess('Season plan created successfully!');
      }
      
      setLoading(false);
      
      // Clear success message after a delay
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
    } catch (err) {
      setError(`Error saving season plan: ${err.message}`);
      setLoading(false);
      console.error(err);
    }
  };
  
  const renderCalendar = () => {
    // This is a simplified calendar view
    // In a real implementation, this would be more sophisticated
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                   'July', 'August', 'September', 'October', 'November', 'December'];
    
    const startDate = new Date(formData.startDate);
    const endDate = new Date(formData.endDate);
    
    const startMonth = startDate.getMonth();
    const startYear = startDate.getFullYear();
    const endMonth = endDate.getMonth();
    const endYear = endDate.getFullYear();
    
    const calendarMonths = [];
    
    // Generate months between start and end dates
    let currentDate = new Date(startYear, startMonth, 1);
    while (currentDate <= endDate) {
      calendarMonths.push({
        month: currentDate.getMonth(),
        year: currentDate.getFullYear()
      });
      
      // Move to next month
      currentDate.setMonth(currentDate.getMonth() + 1);
    }
    
    return (
      <div className="macrocycle-calendar">
        <div className="calendar-header">
          <h4>Season Calendar</h4>
          <div>
            <Button 
              variant={calendarView === 'month' ? 'primary' : 'outline-primary'} 
              size="sm"
              className="me-2"
              onClick={() => setCalendarView('month')}
            >
              Month View
            </Button>
            <Button 
              variant={calendarView === 'list' ? 'primary' : 'outline-primary'} 
              size="sm"
              onClick={() => setCalendarView('list')}
            >
              List View
            </Button>
          </div>
        </div>
        
        {calendarView === 'month' ? (
          // Month view
          calendarMonths.map((calMonth, index) => (
            <div key={`${calMonth.year}-${calMonth.month}`} className="calendar-month">
              <div className="calendar-month-title">
                {months[calMonth.month]} {calMonth.year}
              </div>
              
              {/* Simplified calendar grid */}
              <div className="calendar-week">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="calendar-day-header text-center">
                    {day}
                  </div>
                ))}
              </div>
              
              {/* This is a placeholder for the actual calendar days */}
              {/* In a real implementation, you would generate the actual days */}
              <div className="text-center py-3">
                <em>Calendar days would be generated here</em>
              </div>
            </div>
          ))
        ) : (
          // List view
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Date</th>
                <th>Phase</th>
                <th>Activity</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              {/* This is a placeholder for the actual calendar events */}
              {/* In a real implementation, you would generate the actual events */}
              <tr>
                <td colSpan="4" className="text-center py-3">
                  <em>Calendar events would be listed here</em>
                </td>
              </tr>
            </tbody>
          </Table>
        )}
      </div>
    );
  };
  
  if (loading) {
    return (
      <Container className="planning-container">
        <div className="loading-spinner">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      </Container>
    );
  }
  
  return (
    <Container className="planning-container">
      <div className="planning-header">
        <h1>Season Plan {formData.name && `- ${formData.name}`}</h1>
        <div>
          <Link to={`/age-group/${id}`} className="me-2">
            <Button variant="outline-secondary">
              <FaArrowLeft className="me-2" /> Back to Age Group
            </Button>
          </Link>
          {macrocycle && (
            <Link to={`/macrocycle/${macrocycle.id}/mesocycles`}>
              <Button variant="outline-primary">
                View Mesocycles
              </Button>
            </Link>
          )}
        </div>
      </div>
      
      {error && <Alert variant="danger">{error}</Alert>}
      {success && <Alert variant="success">{success}</Alert>}
      
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={8}>
            <Card className="planning-section">
              <Card.Body>
                <h3>Season Plan Details</h3>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Plan Name</Form.Label>
                      <Form.Control
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Age Group</Form.Label>
                      <Form.Control
                        type="text"
                        value={ageGroupPlan?.ageGroup || ''}
                        disabled
                      />
                    </Form.Group>
                  </Col>
                </Row>
                
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Season Start Date</Form.Label>
                      <Form.Control
                        type="date"
                        name="startDate"
                        value={formData.startDate}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Season End Date</Form.Label>
                      <Form.Control
                        type="date"
                        name="endDate"
                        value={formData.endDate}
                        onChange={handleInputChange}
                      />
                    </Form.Group>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
            
            <Card className="planning-section mt-4">
              <Card.Body>
                <h3>Season Phases</h3>
                <p className="text-muted">Define the phases of your season and their focus areas.</p>
                
                {formData.seasonPhases.map((phase, index) => (
                  <Card key={phase.id} className="mb-3" style={{ borderLeft: `5px solid ${phase.color}` }}>
                    <Card.Body>
                      <Row>
                        <Col md={6}>
                          <Form.Group className="mb-3">
                            <Form.Label>Phase Name</Form.Label>
                            <Form.Control
                              type="text"
                              name={`seasonPhases.${index}.name`}
                              value={phase.name}
                              onChange={handleInputChange}
                            />
                          </Form.Group>
                        </Col>
                        <Col md={6}>
                          <Form.Group className="mb-3">
                            <Form.Label>Color</Form.Label>
                            <Form.Control
                              type="color"
                              name={`seasonPhases.${index}.color`}
                              value={phase.color}
                              onChange={handleInputChange}
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                      
                      <Row>
                        <Col md={6}>
                          <Form.Group className="mb-3">
                            <Form.Label>Start Date</Form.Label>
                            <Form.Control
                              type="date"
                              name={`seasonPhases.${index}.startDate`}
                              value={phase.startDate}
                              onChange={handleInputChange}
                            />
                          </Form.Group>
                        </Col>
                        <Col md={6}>
                          <Form.Group className="mb-3">
                            <Form.Label>End Date</Form.Label>
                            <Form.Control
                              type="date"
                              name={`seasonPhases.${index}.endDate`}
                              value={phase.endDate}
                              onChange={handleInputChange}
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                      
                      <Form.Group className="mb-3">
                        <Form.Label>Focus</Form.Label>
                        <Form.Control
                          as="textarea"
                          rows={2}
                          name={`seasonPhases.${index}.focus`}
                          value={phase.focus}
                          onChange={handleInputChange}
                        />
                      </Form.Group>
                    </Card.Body>
                  </Card>
                ))}
              </Card.Body>
            </Card>
            
            <Card className="planning-section mt-4">
              <Card.Body>
                <h3>Season Calendar</h3>
                {renderCalendar()}
              </Card.Body>
            </Card>
            
            <Card className="planning-section mt-4">
              <Card.Body>
                <h3>Season Goals</h3>
                <Form.Group className="mb-3">
                  <Form.Label>Technical Goals</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="seasonGoals.technical"
                    value={formData.seasonGoals.technical}
                    onChange={handleInputChange}
                    placeholder="Enter technical goals for the season..."
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Tactical Goals</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="seasonGoals.tactical"
                    value={formData.seasonGoals.tactical}
                    onChange={handleInputChange}
                    placeholder="Enter tactical goals for the season..."
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Physical Goals</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="seasonGoals.physical"
                    value={formData.seasonGoals.physical}
                    onChange={handleInputChange}
                    placeholder="Enter physical goals for the season..."
                  />
                </Form.Group>
                
                <Form.Group className="mb-3">
                  <Form.Label>Psychosocial Goals</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="seasonGoals.psychosocial"
                    value={formData.seasonGoals.psychosocial}
                    onChange={handleInputChange}
                    placeholder="Enter psychosocial goals for the season..."
                  />
                </Form.Group>
              </Card.Body>
            </Card>
            
            <Card className="planning-section mt-4">
              <Card.Body>
                <h3>Additional Notes</h3>
                <Form.Group className="mb-3">
                  <Form.Control
                    as="textarea"
                    rows={4}
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="Enter any additional notes about this season plan..."
                  />
                </Form.Group>
              </Card.Body>
            </Card>
            
            <div className="d-grid gap-2 mt-4 mb-4">
              <Button variant="primary" type="submit" size="lg" disabled={loading}>
                {loading ? (
                  <>
                    <Spinner
                      as="span"
                      animation="border"
                      size="sm"
                      role="status"
                      aria-hidden="true"
                      className="me-2"
                    />
                    Saving...
                  </>
                ) : (
                  <>
                    <FaSave className="me-2" /> Save Season Plan
                  </>
                )}
              </Button>
            </div>
          </Col>
          
          <Col md={4}>
            <Card className="planning-section">
              <Card.Body>
                <h3>Plan Summary</h3>
                <p><strong>Age Group:</strong> {ageGroupPlan?.ageGroup || ''}</p>
                <p><strong>Season Duration:</strong> {new Date(formData.startDate).toLocaleDateString()} - {new Date(formData.endDate).toLocaleDateString()}</p>
                <p><strong>Number of Phases:</strong> {formData.seasonPhases.length}</p>
                
                <h5 className="mt-4">Season Phases</h5>
                {formData.seasonPhases.map(phase => (
                  <div key={phase.id} className="mb-3">
                    <div className="d-flex justify-content-between align-items-center">
                      <span>{phase.name}</span>
                      <div 
                        style={{ 
                          width: '20px', 
                          height: '20px', 
                          backgroundColor: phase.color,
                          borderRadius: '3px'
                        }}
                      ></div>
                    </div>
                    <small className="text-muted d-block">
                      {new Date(phase.startDate).toLocaleDateString()} - {new Date(phase.endDate).toLocaleDateString()}
                    </small>
                    <small className="d-block">{phase.focus}</small>
                  </div>
                ))}
              </Card.Body>
            </Card>
            
            <Card className="planning-section mt-4">
              <Card.Body>
                <h3>Next Steps</h3>
                <p>After saving your season plan, you can:</p>
                <ul>
                  <li>Create mesocycles (4-6 week blocks)</li>
                  <li>Plan weekly sessions</li>
                  <li>Create detailed training sessions</li>
                </ul>
                <div className="d-grid gap-2 mt-3">
                  <Button 
                    variant="outline-primary" 
                    disabled={!macrocycle}
                    onClick={() => navigate(`/macrocycle/${macrocycle?.id}/mesocycles`)}
                  >
                    <FaCalendarAlt className="me-2" /> Create Mesocycles
                  </Button>
                </div>
              </Card.Body>
            </Card>
            
            <Card className="planning-section mt-4">
              <Card.Body>
                <h3>Time Distribution</h3>
                <p>Based on the age group settings:</p>
                <div>
                  <div className="d-flex justify-content-between align-items-center mb-1">
                    <span>Technical</span>
                    <span>{ageGroupPlan?.timeDistribution?.technical?.percentage || 0}%</span>
                  </div>
                  <div className="progress mb-3" style={{ height: '10px' }}>
                    <div 
                      className="progress-bar bg-info" 
                      role="progressbar" 
                      style={{ width: `${ageGroupPlan?.timeDistribution?.technical?.percentage || 0}%` }}
                      aria-valuenow={ageGroupPlan?.timeDistribution?.technical?.percentage || 0}
                      aria-valuemin="0" 
                      aria-valuemax="100"
                    ></div>
                  </div>
                  
                  <div className="d-flex justify-content-between align-items-center mb-1">
                    <span>Tactical</span>
                    <span>{ageGroupPlan?.timeDistribution?.tactical?.percentage || 0}%</span>
                  </div>
                  <div className="progress mb-3" style={{ height: '10px' }}>
                    <div 
                      className="progress-bar bg-primary" 
                      role="progressbar" 
                      style={{ width: `${ageGroupPlan?.timeDistribution?.tactical?.percentage || 0}%` }}
                      aria-valuenow={ageGroupPlan?.timeDistribution?.tactical?.percentage || 0}
                      aria-valuemin="0" 
                      aria-valuemax="100"
                    ></div>
                  </div>
                  
                  <div className="d-flex justify-content-between align-items-center mb-1">
                    <span>Physical</span>
                    <span>{ageGroupPlan?.timeDistribution?.physical?.percentage || 0}%</span>
                  </div>
                  <div className="progress mb-3" style={{ height: '10px' }}>
                    <div 
                      className="progress-bar bg-success" 
                      role="progressbar" 
                      style={{ width: `${ageGroupPlan?.timeDistribution?.physical?.percentage || 0}%` }}
                      aria-valuenow={ageGroupPlan?.timeDistribution?.physical?.percentage || 0}
                      aria-valuemin="0" 
                      aria-valuemax="100"
                    ></div>
                  </div>
                  
                  <div className="d-flex justify-content-between align-items-center mb-1">
                    <span>Psychosocial</span>
                    <span>{ageGroupPlan?.timeDistribution?.psychosocial?.percentage || 0}%</span>
                  </div>
                  <div className="progress mb-3" style={{ height: '10px' }}>
                    <div 
                      className="progress-bar bg-warning" 
                      role="progressbar" 
                      style={{ width: `${ageGroupPlan?.timeDistribution?.psychosocial?.percentage || 0}%` }}
                      aria-valuenow={ageGroupPlan?.timeDistribution?.psychosocial?.percentage || 0}
                      aria-valuemin="0" 
                      aria-valuemax="100"
                    ></div>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Form>
    </Container>
  );
};

export default MacrocycleView;
