// src/components/exercises/ExerciseDatabase.js
import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Form, InputGroup, Spinner, Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaSearch, FaPlus, FaEdit, FaTrash } from 'react-icons/fa';
import { getExercises, searchExercises, deleteExercise } from '../../services/exerciseService';
import './ExerciseStyles.css';

const ExerciseDatabase = () => {
  const [exercises, setExercises] = useState([]);
  const [filteredExercises, setFilteredExercises] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedAgeGroups, setSelectedAgeGroups] = useState([]);
  
  const ageGroupOptions = [
    'U4', 'U6', 'U8', 'U9-U10', 'U11-U12', 'U13-U15', 'U16+'
  ];
  
  const categoryOptions = [
    { value: '', label: 'All Categories' },
    { value: 'Technical', label: 'Technical' },
    { value: 'Tactical', label: 'Tactical' },
    { value: 'Physical', label: 'Physical' },
    { value: 'Psychosocial', label: 'Psychosocial' }
  ];

  useEffect(() => {
    fetchExercises();
  }, []);

  const fetchExercises = async () => {
    try {
      setLoading(true);
      const exercisesData = await getExercises();
      setExercises(exercisesData);
      setFilteredExercises(exercisesData);
      setLoading(false);
    } catch (err) {
      setError('Failed to load exercises. Please try again later.');
      setLoading(false);
      console.error(err);
    }
  };

  const handleSearch = async () => {
    try {
      setLoading(true);
      const results = await searchExercises(searchTerm, selectedAgeGroups);
      
      // Apply category filter if selected
      const filtered = selectedCategory 
        ? results.filter(exercise => exercise.category === selectedCategory)
        : results;
      
      setFilteredExercises(filtered);
      setLoading(false);
    } catch (err) {
      setError('Search failed. Please try again.');
      setLoading(false);
      console.error(err);
    }
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
  };

  const handleAgeGroupChange = (e) => {
    const value = e.target.value;
    setSelectedAgeGroups(
      selectedAgeGroups.includes(value)
        ? selectedAgeGroups.filter(group => group !== value)
        : [...selectedAgeGroups, value]
    );
  };

  const handleDeleteExercise = async (id) => {
    if (window.confirm('Are you sure you want to delete this exercise?')) {
      try {
        await deleteExercise(id);
        setExercises(exercises.filter(exercise => exercise.id !== id));
        setFilteredExercises(filteredExercises.filter(exercise => exercise.id !== id));
      } catch (err) {
        setError('Failed to delete exercise. Please try again.');
        console.error(err);
      }
    }
  };

  useEffect(() => {
    // Apply filters whenever filter criteria change
    let results = exercises;
    
    // Filter by search term
    if (searchTerm) {
      results = results.filter(exercise => 
        exercise.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (exercise.description && exercise.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (exercise.objectives && exercise.objectives.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    // Filter by category
    if (selectedCategory) {
      results = results.filter(exercise => exercise.category === selectedCategory);
    }
    
    // Filter by age groups
    if (selectedAgeGroups.length > 0) {
      results = results.filter(exercise => 
        exercise.ageGroups && exercise.ageGroups.some(group => selectedAgeGroups.includes(group))
      );
    }
    
    setFilteredExercises(results);
  }, [searchTerm, selectedCategory, selectedAgeGroups, exercises]);

  const getCategoryClass = (category) => {
    switch(category) {
      case 'Technical': return 'tag-technical';
      case 'Tactical': return 'tag-tactical';
      case 'Physical': return 'tag-physical';
      case 'Psychosocial': return 'tag-psychosocial';
      default: return '';
    }
  };

  return (
    <Container className="exercise-container">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1>Exercise Database</h1>
        <Link to="/exercises/new">
          <Button variant="primary">
            <FaPlus className="me-2" /> Add New Exercise
          </Button>
        </Link>
      </div>

      {error && <Alert variant="danger">{error}</Alert>}

      <div className="exercise-filter">
        <Row>
          <Col md={6}>
            <InputGroup className="mb-3">
              <Form.Control
                placeholder="Search exercises..."
                value={searchTerm}
                onChange={handleSearchChange}
              />
              <Button variant="outline-secondary" onClick={handleSearch}>
                <FaSearch />
              </Button>
            </InputGroup>
          </Col>
          <Col md={3}>
            <Form.Group className="mb-3">
              <Form.Select 
                value={selectedCategory} 
                onChange={handleCategoryChange}
              >
                {categoryOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>
          </Col>
          <Col md={3}>
            <Form.Group className="mb-3">
              <Form.Label>Age Groups</Form.Label>
              <div>
                {ageGroupOptions.map(ageGroup => (
                  <Form.Check
                    key={ageGroup}
                    inline
                    type="checkbox"
                    id={`age-group-${ageGroup}`}
                    label={ageGroup}
                    value={ageGroup}
                    checked={selectedAgeGroups.includes(ageGroup)}
                    onChange={handleAgeGroupChange}
                  />
                ))}
              </div>
            </Form.Group>
          </Col>
        </Row>
      </div>

      {loading ? (
        <div className="loading-spinner">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      ) : (
        <>
          {filteredExercises.length === 0 ? (
            <Alert variant="info">No exercises found. Try adjusting your search criteria or add a new exercise.</Alert>
          ) : (
            <Row xs={1} md={2} lg={3} className="g-4">
              {filteredExercises.map(exercise => (
                <Col key={exercise.id}>
                  <Card className="exercise-card">
                    {exercise.imageUrl ? (
                      <Card.Img variant="top" src={exercise.imageUrl} alt={exercise.name} />
                    ) : (
                      <div className="card-img-top d-flex align-items-center justify-content-center bg-light">
                        <span className="text-muted">No Image</span>
                      </div>
                    )}
                    <Card.Body>
                      <Card.Title>{exercise.name}</Card.Title>
                      <div className="mb-2">
                        {exercise.category && (
                          <span className={`exercise-tag ${getCategoryClass(exercise.category)}`}>
                            {exercise.category}
                          </span>
                        )}
                        {exercise.ageGroups && exercise.ageGroups.map(ageGroup => (
                          <span key={ageGroup} className="exercise-tag tag-age-group">
                            {ageGroup}
                          </span>
                        ))}
                      </div>
                      <Card.Text>
                        {exercise.objectives && exercise.objectives.length > 100
                          ? `${exercise.objectives.substring(0, 100)}...`
                          : exercise.objectives}
                      </Card.Text>
                      <div className="d-flex justify-content-between mt-3">
                        <Link to={`/exercises/${exercise.id}`}>
                          <Button variant="outline-primary" size="sm">View Details</Button>
                        </Link>
                        <div>
                          <Link to={`/exercises/edit/${exercise.id}`} className="me-2">
                            <Button variant="outline-secondary" size="sm">
                              <FaEdit />
                            </Button>
                          </Link>
                          <Button 
                            variant="outline-danger" 
                            size="sm" 
                            onClick={() => handleDeleteExercise(exercise.id)}
                          >
                            <FaTrash />
                          </Button>
                        </div>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          )}
        </>
      )}
    </Container>
  );
};

export default ExerciseDatabase;
