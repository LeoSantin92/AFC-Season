// src/pages/Dashboard.js
import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaFutbol, FaUsers, FaCalendarAlt } from 'react-icons/fa';

function Dashboard() {
  return (
    <Container className="mt-4">
      <h1 className="mb-4">AFC Soccer Planner Dashboard</h1>
      
      <Row className="mb-4">
        <Col>
          <div className="p-4 bg-primary text-white rounded">
            <h2>Welcome to AFC Soccer Planner</h2>
            <p className="lead">
              Your comprehensive solution for soccer training management, season planning, and exercise organization.
            </p>
            <p>
              This application helps coaches create structured training plans following AFC-Huntsville methodologies,
              manage exercises, and organize season plans for multiple age groups.
            </p>
          </div>
        </Col>
      </Row>
      
      <Row>
        <Col md={4} className="mb-4">
          <Card className="h-100">
            <Card.Body className="d-flex flex-column">
              <div className="text-center mb-3">
                <FaFutbol size={50} className="text-primary" />
              </div>
              <Card.Title className="text-center">Exercise Database</Card.Title>
              <Card.Text>
                Create, manage, and organize training exercises for different age groups and categories.
                Filter by technical, tactical, physical, and psychosocial components.
              </Card.Text>
              <div className="mt-auto text-center">
                <Link to="/exercises">
                  <Button variant="outline-primary">Manage Exercises</Button>
                </Link>
              </div>
            </Card.Body>
          </Card>
        </Col>
        
        <Col md={4} className="mb-4">
          <Card className="h-100">
            <Card.Body className="d-flex flex-column">
              <div className="text-center mb-3">
                <FaUsers size={50} className="text-success" />
              </div>
              <Card.Title className="text-center">Age Group Management</Card.Title>
              <Card.Text>
                Set up and manage multiple age groups with specific training parameters, session durations,
                and development priorities based on AFC-Huntsville methodologies.
              </Card.Text>
              <div className="mt-auto text-center">
                <Link to="/age-groups">
                  <Button variant="outline-success">Manage Age Groups</Button>
                </Link>
              </div>
            </Card.Body>
          </Card>
        </Col>
        
        <Col md={4} className="mb-4">
          <Card className="h-100">
            <Card.Body className="d-flex flex-column">
              <div className="text-center mb-3">
                <FaCalendarAlt size={50} className="text-info" />
              </div>
              <Card.Title className="text-center">Season Planning</Card.Title>
              <Card.Text>
                Create comprehensive season plans with macrocycles, mesocycles, weekly plans, and
                detailed session templates following tactical periodization principles.
              </Card.Text>
              <div className="mt-auto text-center">
                <Link to="/age-groups">
                  <Button variant="outline-info">Start Planning</Button>
                </Link>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      <Row className="mt-4">
        <Col>
          <Card>
            <Card.Body>
              <h4>Getting Started</h4>
              <ol>
                <li>Create exercises in the Exercise Database</li>
                <li>Set up age groups with appropriate parameters</li>
                <li>Create a season plan for each age group</li>
                <li>Define mesocycles within the season</li>
                <li>Create weekly plans with specific objectives</li>
                <li>Design detailed training sessions</li>
              </ol>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default Dashboard;
