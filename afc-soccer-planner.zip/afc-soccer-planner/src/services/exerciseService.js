// src/services/exerciseService.js
import { db, storage } from '../firebase';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  getDoc,
  where,
  query
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { v4 as uuidv4 } from 'uuid';

const exercisesCollectionRef = collection(db, 'exercises');

// Get all exercises
export const getExercises = async () => {
  const data = await getDocs(exercisesCollectionRef);
  return data.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
};

// Search exercises by name, description, or objectives
export const searchExercises = async (searchTerm, ageGroups = []) => {
  const exercises = await getExercises();
  
  return exercises.filter(exercise => {
    // Filter by search term
    const matchesSearch = searchTerm === '' || 
      exercise.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (exercise.description && exercise.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (exercise.objectives && exercise.objectives.toLowerCase().includes(searchTerm.toLowerCase()));
    
    // Filter by age groups if provided
    const matchesAgeGroup = ageGroups.length === 0 || 
      (exercise.ageGroups && exercise.ageGroups.some(group => ageGroups.includes(group)));
    
    return matchesSearch && matchesAgeGroup;
  });
};

// Add a new exercise
export const addExercise = async (exercise, imageFile) => {
  try {
    let imageUrl = '';
    
    // Upload image if provided
    if (imageFile) {
      const imageRef = ref(storage, `exercises/${uuidv4()}`);
      await uploadBytes(imageRef, imageFile);
      imageUrl = await getDownloadURL(imageRef);
    }
    
    // Add exercise with image URL
    const exerciseWithImage = {
      ...exercise,
      imageUrl,
      createdAt: new Date()
    };
    
    const docRef = await addDoc(exercisesCollectionRef, exerciseWithImage);
    return { id: docRef.id, ...exerciseWithImage };
  } catch (error) {
    console.error("Error adding exercise: ", error);
    throw new Error(`Error saving exercise: ${error.message}`);
  }
};

// Update an existing exercise
export const updateExercise = async (id, updatedExercise, imageFile) => {
  try {
    const exerciseDoc = doc(db, 'exercises', id);
    const exerciseSnapshot = await getDoc(exerciseDoc);
    
    if (!exerciseSnapshot.exists()) {
      throw new Error('Exercise not found');
    }
    
    const currentExercise = exerciseSnapshot.data();
    let imageUrl = currentExercise.imageUrl || '';
    
    // Handle image update
    if (imageFile) {
      // Delete old image if it exists
      if (imageUrl) {
        try {
          const oldImageRef = ref(storage, imageUrl);
          await deleteObject(oldImageRef);
        } catch (error) {
          console.log('Old image not found or already deleted');
        }
      }
      
      // Upload new image
      const imageRef = ref(storage, `exercises/${uuidv4()}`);
      await uploadBytes(imageRef, imageFile);
      imageUrl = await getDownloadURL(imageRef);
    }
    
    // Update exercise with new data
    const exerciseWithUpdates = {
      ...updatedExercise,
      imageUrl,
      updatedAt: new Date()
    };
    
    await updateDoc(exerciseDoc, exerciseWithUpdates);
    return { id, ...exerciseWithUpdates };
  } catch (error) {
    console.error("Error updating exercise: ", error);
    throw new Error(`Error updating exercise: ${error.message}`);
  }
};

// Delete an exercise
export const deleteExercise = async (id) => {
  try {
    const exerciseDoc = doc(db, 'exercises', id);
    const exerciseSnapshot = await getDoc(exerciseDoc);
    
    if (!exerciseSnapshot.exists()) {
      throw new Error('Exercise not found');
    }
    
    const exercise = exerciseSnapshot.data();
    
    // Delete image if it exists
    if (exercise.imageUrl) {
      try {
        const imageRef = ref(storage, exercise.imageUrl);
        await deleteObject(imageRef);
      } catch (error) {
        console.log('Image not found or already deleted');
      }
    }
    
    // Delete exercise document
    await deleteDoc(exerciseDoc);
    return id;
  } catch (error) {
    console.error("Error deleting exercise: ", error);
    throw new Error(`Error deleting exercise: ${error.message}`);
  }
};
