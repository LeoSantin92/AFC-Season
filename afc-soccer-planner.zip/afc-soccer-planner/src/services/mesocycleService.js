// src/services/mesocycleService.js
import { db } from '../firebase';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  getDoc,
  query,
  where
} from 'firebase/firestore';

const mesocyclesCollectionRef = collection(db, 'mesocycles');

// Get mesocycles by macrocycle ID
export const getMesocyclesByMacrocycleId = async (macrocycleId) => {
  try {
    const q = query(mesocyclesCollectionRef, where("macrocycleId", "==", macrocycleId));
    const data = await getDocs(q);
    return data.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
  } catch (error) {
    console.error("Error getting mesocycles: ", error);
    throw error;
  }
};

// Get a specific mesocycle
export const getMesocycle = async (id) => {
  try {
    const mesocycleDoc = await getDoc(doc(db, 'mesocycles', id));
    
    if (mesocycleDoc.exists()) {
      return { id: mesocycleDoc.id, ...mesocycleDoc.data() };
    } else {
      throw new Error('Mesocycle not found');
    }
  } catch (error) {
    console.error("Error getting mesocycle: ", error);
    throw error;
  }
};

// Create a new mesocycle
export const createMesocycle = async (mesocycle) => {
  try {
    const docRef = await addDoc(mesocyclesCollectionRef, {
      ...mesocycle,
      createdAt: new Date()
    });
    return { id: docRef.id, ...mesocycle };
  } catch (error) {
    console.error("Error creating mesocycle: ", error);
    throw error;
  }
};

// Update an existing mesocycle
export const updateMesocycle = async (id, updatedMesocycle) => {
  try {
    const mesocycleDoc = doc(db, 'mesocycles', id);
    await updateDoc(mesocycleDoc, {
      ...updatedMesocycle,
      updatedAt: new Date()
    });
    return { id, ...updatedMesocycle };
  } catch (error) {
    console.error("Error updating mesocycle: ", error);
    throw error;
  }
};

// Delete a mesocycle
export const deleteMesocycle = async (id) => {
  try {
    const mesocycleDoc = doc(db, 'mesocycles', id);
    await deleteDoc(mesocycleDoc);
    return id;
  } catch (error) {
    console.error("Error deleting mesocycle: ", error);
    throw error;
  }
};
