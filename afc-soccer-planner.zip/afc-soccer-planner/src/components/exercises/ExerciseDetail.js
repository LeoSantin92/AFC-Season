// src/components/exercises/ExerciseDetail.js
import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Spinner, Alert, Tabs, Tab } from 'react-bootstrap';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { FaEdit, FaTrash, FaArrowLeft } from 'react-icons/fa';
import { getDoc, doc } from 'firebase/firestore';
import { db } from '../../firebase';
import { deleteExercise } from '../../services/exerciseService';
import './ExerciseStyles.css';

const ExerciseDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [exercise, setExercise] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchExercise = async () => {
      try {
        setLoading(true);
        const exerciseDoc = await getDoc(doc(db, 'exercises', id));
        
        if (exerciseDoc.exists()) {
          setExercise({ id: exerciseDoc.id, ...exerciseDoc.data() });
        } else {
          setError('Exercise not found');
        }
        
        setLoading(false);
      } catch (err) {
        setError('Failed to load exercise details. Please try again later.');
        setLoading(false);
        console.error(err);
      }
    };

    fetchExercise();
  }, [id]);

  const handleDeleteExercise = async () => {
    if (window.confirm('Are you sure you want to delete this exercise?')) {
      try {
        await deleteExercise(id);
        navigate('/exercises');
      } catch (err) {
        setError('Failed to delete exercise. Please try again.');
        console.error(err);
      }
    }
  };

  const getCategoryClass = (category) => {
    switch(category) {
      case 'Technical': return 'tag-technical';
      case 'Tactical': return 'tag-tactical';
      case 'Physical': return 'tag-physical';
      case 'Psychosocial': return 'tag-psychosocial';
      default: return '';
    }
  };

  if (loading) {
    return (
      <Container className="exercise-detail-container">
        <div className="loading-spinner">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      </Container>
    );
  }

  if (error) {
    return (
      <Container className="exercise-detail-container">
        <Alert variant="danger">{error}</Alert>
        <Link to="/exercises">
          <Button variant="primary">
            <FaArrowLeft className="me-2" /> Back to Exercises
          </Button>
        </Link>
      </Container>
    );
  }

  if (!exercise) {
    return (
      <Container className="exercise-detail-container">
        <Alert variant="warning">Exercise not found</Alert>
        <Link to="/exercises">
          <Button variant="primary">
            <FaArrowLeft className="me-2" /> Back to Exercises
          </Button>
        </Link>
      </Container>
    );
  }

  return (
    <Container className="exercise-detail-container">
      <div className="exercise-detail-header">
        <h1>{exercise.name}</h1>
        <div>
          <Link to="/exercises" className="me-2">
            <Button variant="outline-secondary">
              <FaArrowLeft className="me-2" /> Back
            </Button>
          </Link>
          <Link to={`/exercises/edit/${id}`} className="me-2">
            <Button variant="outline-primary">
              <FaEdit className="me-2" /> Edit
            </Button>
          </Link>
          <Button variant="outline-danger" onClick={handleDeleteExercise}>
            <FaTrash className="me-2" /> Delete
          </Button>
        </div>
      </div>

      <Row className="mb-4">
        <Col md={6}>
          {exercise.imageUrl ? (
            <img 
              src={exercise.imageUrl} 
              alt={exercise.name} 
              className="exercise-detail-image" 
            />
          ) : (
            <div className="exercise-detail-image d-flex align-items-center justify-content-center bg-light">
              <span className="text-muted">No Image Available</span>
            </div>
          )}
        </Col>
        <Col md={6}>
          <Card>
            <Card.Body>
              <h4>Overview</h4>
              <div className="mb-3">
                {exercise.category && (
                  <span className={`exercise-tag ${getCategoryClass(exercise.category)}`}>
                    {exercise.category}
                  </span>
                )}
                {exercise.ageGroups && exercise.ageGroups.map(ageGroup => (
                  <span key={ageGroup} className="exercise-tag tag-age-group">
                    {ageGroup}
                  </span>
                ))}
              </div>
              
              <p><strong>Objectives:</strong> {exercise.objectives}</p>
              
              {exercise.playerCount && (
                <p><strong>Number of Players:</strong> {exercise.playerCount}</p>
              )}
              
              {exercise.duration && (
                <p><strong>Duration:</strong> {exercise.duration} minutes</p>
              )}
              
              {exercise.fieldSize && (
                <p><strong>Field Size:</strong> {exercise.fieldSize}</p>
              )}
              
              {exercise.equipment && (
                <p><strong>Equipment:</strong> {exercise.equipment}</p>
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Tabs defaultActiveKey="description" className="mb-4">
        <Tab eventKey="description" title="Description">
          <Card>
            <Card.Body>
              <h4>Description</h4>
              <p>{exercise.description}</p>
            </Card.Body>
          </Card>
        </Tab>
        
        <Tab eventKey="setup" title="Setup & Organization">
          <Card>
            <Card.Body>
              <h4>Setup & Organization</h4>
              <p>{exercise.setup || 'No setup information provided.'}</p>
            </Card.Body>
          </Card>
        </Tab>
        
        <Tab eventKey="coaching" title="Coaching Points">
          <Card>
            <Card.Body>
              <h4>Coaching Points</h4>
              <p>{exercise.coachingPoints || 'No coaching points provided.'}</p>
            </Card.Body>
          </Card>
        </Tab>
        
        <Tab eventKey="progressions" title="Progressions">
          <Card>
            <Card.Body>
              <h4>Progressions</h4>
              <p>{exercise.progressions || 'No progressions provided.'}</p>
            </Card.Body>
          </Card>
        </Tab>
      </Tabs>
    </Container>
  );
};

export default ExerciseDetail;
